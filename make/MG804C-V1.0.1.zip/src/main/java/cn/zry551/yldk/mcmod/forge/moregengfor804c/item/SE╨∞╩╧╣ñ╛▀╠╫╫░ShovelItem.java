
package cn.zry551.yldk.mcmod.forge.moregengfor804c.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures.SEXuShiGongJuTaoZhuangPickaxeDangShiTiBeiGongJuJiZhongShiProcedure;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModTabs;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModItems;

public class SE���Ϲ�����װShovelItem extends ShovelItem {
	public SE���Ϲ�����װShovelItem() {
		super(new Tier() {
			public int getUses() {
				return 32767;
			}

			public float getSpeed() {
				return 256f;
			}

			public float getAttackDamageBonus() {
				return 0f;
			}

			public int getLevel() {
				return 5;
			}

			public int getEnchantmentValue() {
				return 36;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(MoregengFor804cModItems.XU_SHI_XIAO_DAO));
			}
		}, 1, -3f, new Item.Properties().tab(MoregengFor804cModTabs.TAB_MORE_GENG_804_CARD).fireResistant());
		setRegistryName("se_xu_shi_gong_ju_tao_zhuang_shovel");
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		Level world = entity.level;

		SEXuShiGongJuTaoZhuangPickaxeDangShiTiBeiGongJuJiZhongShiProcedure.execute(entity, itemstack);
		return retval;
	}
}
