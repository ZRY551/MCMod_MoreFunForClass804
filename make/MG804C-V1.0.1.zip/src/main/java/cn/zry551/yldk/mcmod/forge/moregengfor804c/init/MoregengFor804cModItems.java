
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import java.util.List;
import java.util.ArrayList;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.XuShiXiaoDaoItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SWYiYongJiuJingItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SJiuJingJiShuItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SE��𵶼�ArmorItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SE���Ϲ�����װSwordItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SE���Ϲ�����װShovelItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SE���Ϲ�����װPickaxeItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SE���Ϲ�����װHoeItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.SE���Ϲ�����װAxeItem;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.item.LLaoChenZhiLiItem;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MoregengFor804cModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item XU_SHI_XIAO_DAO = register(new XuShiXiaoDaoItem());
	public static final Item SW_LAO_CUI_DE_BEI_SHANG = register(
			new SpawnEggItem(MoregengFor804cModEntities.SW_LAO_CUI_DE_BEI_SHANG, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("sw_lao_cui_de_bei_shang_spawn_egg"));
	public static final Item SW_LAO_CUI_ZHAO_HUAN_QI = register(MoregengFor804cModBlocks.SW_LAO_CUI_ZHAO_HUAN_QI,
			MoregengFor804cModTabs.TAB_MORE_GENG_804_CARD);
	public static final Item SE_CUI_HUO_DAO_JIA_ARMOR_HELMET = register(new SE��𵶼�ArmorItem.Helmet());
	public static final Item SE_CUI_HUO_DAO_JIA_ARMOR_CHESTPLATE = register(new SE��𵶼�ArmorItem.Chestplate());
	public static final Item SE_CUI_HUO_DAO_JIA_ARMOR_LEGGINGS = register(new SE��𵶼�ArmorItem.Leggings());
	public static final Item SE_CUI_HUO_DAO_JIA_ARMOR_BOOTS = register(new SE��𵶼�ArmorItem.Boots());
	public static final Item SE_XU_SHI_GONG_JU_TAO_ZHUANG_PICKAXE = register(new SE���Ϲ�����װPickaxeItem());
	public static final Item SE_XU_SHI_GONG_JU_TAO_ZHUANG_AXE = register(new SE���Ϲ�����װAxeItem());
	public static final Item SE_XU_SHI_GONG_JU_TAO_ZHUANG_SWORD = register(new SE���Ϲ�����װSwordItem());
	public static final Item SE_XU_SHI_GONG_JU_TAO_ZHUANG_SHOVEL = register(new SE���Ϲ�����װShovelItem());
	public static final Item SE_XU_SHI_GONG_JU_TAO_ZHUANG_HOE = register(new SE���Ϲ�����װHoeItem());
	public static final Item SW_YI_YONG_JIU_JING = register(new SWYiYongJiuJingItem());
	public static final Item S_JIU_JING_JI_SHU = register(new SJiuJingJiShuItem());
	public static final Item L_LAO_CHEN_ZHI_LI = register(new LLaoChenZhiLiItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
