
package cn.zry551.yldk.mcmod.forge.moregengfor804c.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import java.util.List;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures.XuShiXiaoDaoDangShiTiBeiGongJuJiZhongShiProcedure;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModTabs;

public class XuShiXiaoDaoItem extends SwordItem {
	public XuShiXiaoDaoItem() {
		super(new Tier() {
			public int getUses() {
				return 32767;
			}

			public float getSpeed() {
				return 256f;
			}

			public float getAttackDamageBonus() {
				return 34f;
			}

			public int getLevel() {
				return 6;
			}

			public int getEnchantmentValue() {
				return 64;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(Items.IRON_INGOT));
			}
		}, 3, 2f, new Item.Properties().tab(MoregengFor804cModTabs.TAB_MORE_GENG_804_CARD).fireResistant());
		setRegistryName("xu_shi_xiao_dao");
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		Level world = entity.level;

		XuShiXiaoDaoDangShiTiBeiGongJuJiZhongShiProcedure.execute(entity, itemstack);
		return retval;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent("\u7ECF\u8FC7\u4E03\u4E03\u56DB\u5341\u4E5D\u5929\u6DEC\u706B\u7684\u5C0F\u5200"));
	}
}
