
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.decoration.Motive;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MoregengFor804cModPaintings {
	@SubscribeEvent
	public static void registerMotives(RegistryEvent.Register<Motive> event) {
		event.getRegistry().register(new Motive(16, 32).setRegistryName("l_lao_cui_xiang"));
		event.getRegistry().register(new Motive(16, 16).setRegistryName("l_lao_chen_zhuan_xin_biao_qing_bao"));
		event.getRegistry().register(new Motive(32, 32).setRegistryName("l_lao_ba_biao_qing_bao"));
	}
}
