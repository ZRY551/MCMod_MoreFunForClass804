
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.client.renderer.SWLaoCuiDeBeiShangRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MoregengFor804cModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MoregengFor804cModEntities.SW_LAO_CUI_DE_BEI_SHANG, SWLaoCuiDeBeiShangRenderer::new);
	}
}
