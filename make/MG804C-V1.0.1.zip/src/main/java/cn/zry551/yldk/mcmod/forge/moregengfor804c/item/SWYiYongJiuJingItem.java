
package cn.zry551.yldk.mcmod.forge.moregengfor804c.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import java.util.List;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures.SWYiYongJiuJingDangShiWuBeiChiShiProcedure;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures.SWYiYongJiuJingDangHuoZhaoDeShiTiBeiGaiWuPinJiZhongProcedure;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModTabs;

public class SWYiYongJiuJingItem extends Item {
	public SWYiYongJiuJingItem() {
		super(new Item.Properties().tab(MoregengFor804cModTabs.TAB_MORE_GENG_804_CARD).stacksTo(64).rarity(Rarity.UNCOMMON)
				.food((new FoodProperties.Builder()).nutrition(800).saturationMod(800f).alwaysEat().meat().build()));
		setRegistryName("sw_yi_yong_jiu_jing");
	}

	@Override
	public int getUseDuration(ItemStack stack) {
		return 60;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent(
				"\u5F90\u6C0F\u6DEC\u706B\u7528\u4E13\u7528\u9152\u7CBE\uFF0C\u5DF2\u7ECF\u8FC7\u671F4\u5E74\u4EE5\u4E0A\u3002\u6211\u4EEC\u7CBE\u5FC3\u6311\u9009\u53EA\u4E3A\u505A\u51FA\u4E00\u74F6\u597D\u7528\u7684\u6DEC\u706B\u9152\u7CBE\u3002\uFF08\u6613\u71C3\u6613\u7206\uFF0C\u5C0F\u5FC3\u4F7F\u7528\uFF09"));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();

		SWYiYongJiuJingDangShiWuBeiChiShiProcedure.execute(world, x, y, z, entity);
		return retval;
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		SWYiYongJiuJingDangHuoZhaoDeShiTiBeiGaiWuPinJiZhongProcedure.execute(entity.level, entity.getX(), entity.getY(), entity.getZ(), entity,
				sourceentity);
		return retval;
	}
}
