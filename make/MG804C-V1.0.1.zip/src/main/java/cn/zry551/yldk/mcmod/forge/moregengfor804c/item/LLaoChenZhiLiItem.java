
package cn.zry551.yldk.mcmod.forge.moregengfor804c.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import java.util.List;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModTabs;

public class LLaoChenZhiLiItem extends SwordItem {
	public LLaoChenZhiLiItem() {
		super(new Tier() {
			public int getUses() {
				return 3500;
			}

			public float getSpeed() {
				return 4f;
			}

			public float getAttackDamageBonus() {
				return 14f;
			}

			public int getLevel() {
				return 6;
			}

			public int getEnchantmentValue() {
				return 35;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.EMPTY;
			}
		}, 3, -1f, new Item.Properties().tab(MoregengFor804cModTabs.TAB_MORE_GENG_804_CARD));
		setRegistryName("l_lao_chen_zhi_li");
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent("\u51DD\u7ED3\u4E86\u8001\u9648\u5F3A\u5927\u529B\u91CF\u7684\u7269\u54C1"));
	}
}
