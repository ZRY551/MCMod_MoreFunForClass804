package cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

import javax.annotation.Nullable;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModEnchantments;

@Mod.EventBusSubscriber
public class FMEventsProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			Entity entity = event.getEntity();
			execute(event, entity, event.getSource().getEntity());
		}
	}

	public static void execute(Entity entity, Entity sourceentity) {
		execute(null, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		entity.hurt(DamageSource.GENERIC, (float) (EnchantmentHelper.getItemEnchantmentLevel(MoregengFor804cModEnchantments.XU_SHI_BIAO_MIAN_CUI_HUO,
				(sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) * 2.5));
		entity.hurt(DamageSource.GENERIC,
				(float) (EnchantmentHelper.getItemEnchantmentLevel(MoregengFor804cModEnchantments.SW_XU_SHI_GONG_YI_CHUANG_LIAN_CUI_HUO_ZHU,
						(sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) * 20));
		entity.hurt(DamageSource.GENERIC, (float) (EnchantmentHelper.getItemEnchantmentLevel(MoregengFor804cModEnchantments.XU_SHI_BIAO_MIAN_CUI_HUO,
				(sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)) * 2));
		entity.hurt(DamageSource.GENERIC,
				(float) (EnchantmentHelper.getItemEnchantmentLevel(MoregengFor804cModEnchantments.SW_XU_SHI_GONG_YI_CHUANG_LIAN_CUI_HUO_ZHU,
						(sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY)) * 15));
	}
}
