
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;

public class MoregengFor804cModTabs {
	public static CreativeModeTab TAB_MORE_GENG_804_CARD;

	public static void load() {
		TAB_MORE_GENG_804_CARD = new CreativeModeTab("tabmore_geng_804_card") {
			@Override
			public ItemStack makeIcon() {
				return new ItemStack(Blocks.BEACON);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return true;
			}
		}.setBackgroundSuffix("item_search.png");
	}
}
