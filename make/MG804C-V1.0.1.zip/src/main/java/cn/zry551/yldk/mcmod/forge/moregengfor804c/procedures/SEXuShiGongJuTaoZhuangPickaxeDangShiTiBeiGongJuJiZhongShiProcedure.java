package cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures;

import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModEnchantments;

public class SEXuShiGongJuTaoZhuangPickaxeDangShiTiBeiGongJuJiZhongShiProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		entity.hurt(DamageSource.GENERIC,
				(float) (EnchantmentHelper.getItemEnchantmentLevel(MoregengFor804cModEnchantments.XU_SHI_BIAO_MIAN_CUI_HUO, itemstack) * 5));
		entity.hurt(DamageSource.GENERIC, (float) (EnchantmentHelper
				.getItemEnchantmentLevel(MoregengFor804cModEnchantments.SW_XU_SHI_GONG_YI_CHUANG_LIAN_CUI_HUO_ZHU, itemstack) * 75));
	}
}
