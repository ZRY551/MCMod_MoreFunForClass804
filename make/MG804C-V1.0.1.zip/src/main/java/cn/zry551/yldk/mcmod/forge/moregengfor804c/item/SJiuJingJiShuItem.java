
package cn.zry551.yldk.mcmod.forge.moregengfor804c.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;

import java.util.List;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures.SWYiYongJiuJingDangHuoZhaoDeShiTiBeiGaiWuPinJiZhongProcedure;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModTabs;

public class SJiuJingJiShuItem extends Item {
	public SJiuJingJiShuItem() {
		super(new Item.Properties().tab(MoregengFor804cModTabs.TAB_MORE_GENG_804_CARD).stacksTo(64).rarity(Rarity.RARE));
		setRegistryName("s_jiu_jing_ji_shu");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level world, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, world, list, flag);
		list.add(new TextComponent("\u4E00\u5806\u6DEC\u706B\u9152\u7CBE\uFF0C\u6216\u8BB8...\u5A01\u529B\u66F4\u5927\uFF1F"));
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		SWYiYongJiuJingDangHuoZhaoDeShiTiBeiGaiWuPinJiZhongProcedure.execute(entity.level, entity.getX(), entity.getY(), entity.getZ(), entity,
				sourceentity);
		return retval;
	}
}
