
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;

@Mod.EventBusSubscriber
public class MoregengFor804cModFuels {
	@SubscribeEvent
	public static void furnaceFuelBurnTimeEvent(FurnaceFuelBurnTimeEvent event) {
		if (event.getItemStack().getItem() == MoregengFor804cModItems.SW_YI_YONG_JIU_JING)
			event.setBurnTime(32767);
	}
}
