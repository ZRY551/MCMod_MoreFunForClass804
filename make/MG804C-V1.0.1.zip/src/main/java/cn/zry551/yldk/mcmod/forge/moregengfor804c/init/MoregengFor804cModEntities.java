
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import java.util.List;
import java.util.ArrayList;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.entity.SWLaoCuiDeBeiShangEntity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MoregengFor804cModEntities {
	private static final List<EntityType<?>> REGISTRY = new ArrayList<>();
	public static final EntityType<SWLaoCuiDeBeiShangEntity> SW_LAO_CUI_DE_BEI_SHANG = register("sw_lao_cui_de_bei_shang",
			EntityType.Builder.<SWLaoCuiDeBeiShangEntity>of(SWLaoCuiDeBeiShangEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(96).setUpdateInterval(3).setCustomClientFactory(SWLaoCuiDeBeiShangEntity::new).sized(0.6f, 1.8f));

	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		EntityType<T> entityType = (EntityType<T>) entityTypeBuilder.build(registryname).setRegistryName(registryname);
		REGISTRY.add(entityType);
		return entityType;
	}

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new EntityType[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SWLaoCuiDeBeiShangEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SW_LAO_CUI_DE_BEI_SHANG, SWLaoCuiDeBeiShangEntity.createAttributes().build());
	}
}
