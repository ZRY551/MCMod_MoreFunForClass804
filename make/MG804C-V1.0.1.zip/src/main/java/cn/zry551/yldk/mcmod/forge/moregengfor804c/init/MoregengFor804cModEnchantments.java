
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package cn.zry551.yldk.mcmod.forge.moregengfor804c.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.enchantment.Enchantment;

import java.util.List;
import java.util.ArrayList;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.enchantment.XuShiBiaoMianCuiHuoEnchantment;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.enchantment.SWXuShiGongYiChuangLianCuiHuoZhuEnchantment;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MoregengFor804cModEnchantments {
	private static final List<Enchantment> REGISTRY = new ArrayList<>();
	public static final Enchantment XU_SHI_BIAO_MIAN_CUI_HUO = register("moregeng_for_804c:xu_shi_biao_mian_cui_huo",
			new XuShiBiaoMianCuiHuoEnchantment());
	public static final Enchantment SW_XU_SHI_GONG_YI_CHUANG_LIAN_CUI_HUO_ZHU = register(
			"moregeng_for_804c:sw_xu_shi_gong_yi_chuang_lian_cui_huo_zhu", new SWXuShiGongYiChuangLianCuiHuoZhuEnchantment());

	private static Enchantment register(String registryname, Enchantment enchantment) {
		REGISTRY.add(enchantment.setRegistryName(registryname));
		return enchantment;
	}

	@SubscribeEvent
	public static void registerEnchantments(RegistryEvent.Register<Enchantment> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Enchantment[0]));
	}
}
