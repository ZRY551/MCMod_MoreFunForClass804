package cn.zry551.yldk.mcmod.forge.moregengfor804c.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import cn.zry551.yldk.mcmod.forge.moregengfor804c.init.MoregengFor804cModEntities;
import cn.zry551.yldk.mcmod.forge.moregengfor804c.entity.SWLaoCuiDeBeiShangEntity;

public class SWLaoCuiZhaoHuanQiZaiFangKuaiShangYouJianProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = new SWLaoCuiDeBeiShangEntity(MoregengFor804cModEntities.SW_LAO_CUI_DE_BEI_SHANG, _level);
			entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
			if (entityToSpawn instanceof Mob _mobToSpawn)
				_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
			world.addFreshEntity(entityToSpawn);
		}
		world.setBlock(new BlockPos((int) x, (int) y, (int) z), Blocks.BOOKSHELF.defaultBlockState(), 3);
	}
}
