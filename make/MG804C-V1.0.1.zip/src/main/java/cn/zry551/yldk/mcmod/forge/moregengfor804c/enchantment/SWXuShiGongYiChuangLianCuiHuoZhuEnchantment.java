
package cn.zry551.yldk.mcmod.forge.moregengfor804c.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;

public class SWXuShiGongYiChuangLianCuiHuoZhuEnchantment extends Enchantment {
	public SWXuShiGongYiChuangLianCuiHuoZhuEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.BREAKABLE, slots);
	}

	@Override
	public int getMaxLevel() {
		return 10;
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}
}
